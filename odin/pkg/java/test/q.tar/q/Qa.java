package q;

public class Qa {
    public static String f() {
        return "Qa";
    }
    public static String g() {
        return Qb.f();
    }
}
