package q;

public class Q {
    public static void main(String[] args) {
        System.out.println(Qa.g());
    }
}
