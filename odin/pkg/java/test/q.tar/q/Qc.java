package q;

public class Qc {
    public static String f() {
        return "Qc";
    }
}
