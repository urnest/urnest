package q;

public class Qb {
    public static String f() {
        return Qa.f()+"Qb"+Qc.f();
    }
}
